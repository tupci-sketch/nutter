import{r as g,R as j}from"./react-4e769698.js";import{g as V}from"./pixi-89e084c8.js";const y=e=>{let t;const r=new Set,o=(s,f)=>{const a=typeof s=="function"?s(t):s;if(!Object.is(a,t)){const i=t;t=f??(typeof a!="object"||a===null)?a:Object.assign({},t,a),r.forEach(c=>c(t,i))}},n=()=>t,E={setState:o,getState:n,getInitialState:()=>v,subscribe:s=>(r.add(s),()=>r.delete(s)),destroy:()=>{r.clear()}},v=t=e(o,n,E);return E},x=e=>e?y(e):y;var h={exports:{}},R={},w={exports:{}},O={};/**
 * @license React
 * use-sync-external-store-shim.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var d=g;function I(e,t){return e===t&&(e!==0||1/e===1/t)||e!==e&&t!==t}var $=typeof Object.is=="function"?Object.is:I,A=d.useState,F=d.useEffect,P=d.useLayoutEffect,W=d.useDebugValue;function z(e,t){var r=t(),o=A({inst:{value:r,getSnapshot:t}}),n=o[0].inst,u=o[1];return P(function(){n.value=r,n.getSnapshot=t,b(n)&&u({inst:n})},[e,r,t]),F(function(){return b(n)&&u({inst:n}),e(function(){b(n)&&u({inst:n})})},[e]),W(r),r}function b(e){var t=e.getSnapshot;e=e.value;try{var r=t();return!$(e,r)}catch{return!0}}function M(e,t){return t()}var _=typeof window>"u"||typeof window.document>"u"||typeof window.document.createElement>"u"?M:z;O.useSyncExternalStore=d.useSyncExternalStore!==void 0?d.useSyncExternalStore:_;w.exports=O;var C=w.exports;/**
 * @license React
 * use-sync-external-store-shim/with-selector.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var p=g,L=C;function T(e,t){return e===t&&(e!==0||1/e===1/t)||e!==e&&t!==t}var U=typeof Object.is=="function"?Object.is:T,B=L.useSyncExternalStore,q=p.useRef,G=p.useEffect,k=p.useMemo,H=p.useDebugValue;R.useSyncExternalStoreWithSelector=function(e,t,r,o,n){var u=q(null);if(u.current===null){var l={hasValue:!1,value:null};u.current=l}else l=u.current;u=k(function(){function E(i){if(!v){if(v=!0,s=i,i=o(i),n!==void 0&&l.hasValue){var c=l.value;if(n(c,i))return f=c}return f=i}if(c=f,U(s,i))return c;var m=o(i);return n!==void 0&&n(c,m)?(s=i,c):(s=i,f=m)}var v=!1,s,f,a=r===void 0?null:r;return[function(){return E(t())},a===null?void 0:function(){return E(a())}]},[t,r,o,n]);var S=B(e,u[0],u[1]);return G(function(){l.hasValue=!0,l.value=S},[S]),H(S),S};h.exports=R;var J=h.exports;const K=V(J),{useDebugValue:N}=j,{useSyncExternalStoreWithSelector:Q}=K;const X=e=>e;function Y(e,t=X,r){const o=Q(e.subscribe,e.getState,e.getServerState||e.getInitialState,t,r);return N(o),o}const D=e=>{const t=typeof e=="function"?x(e):e,r=(o,n)=>Y(t,o,n);return Object.assign(r,t),r},te=e=>e?D(e):D;export{te as c};
//# sourceMappingURL=zustand-224970ca.js.map
